
import pygame

import moyu_engine.config.constants as C

pygame.init()

font1 = pygame.font.Font('moyu_engine/assets/font/方正像素16.TTF', 35)