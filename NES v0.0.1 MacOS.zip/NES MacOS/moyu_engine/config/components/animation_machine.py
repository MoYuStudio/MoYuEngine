import pygame
import time
 
def animation():
    pass




"""
pygame.init()

window = pygame.display.set_mode([400, 400])

names = locals()
balls = []

for i in range(0, 5):
    dir="T%d"%(i)+ ".png"
    names[i] = pygame.image.load(dir).convert_alpha()
    balls.append(names[i])

while True:
    for i in range(0, 5):
        window.blit(balls[i], (0, 0))
        time.sleep(0.5)
        pygame.display.update()
        print(i)
 """