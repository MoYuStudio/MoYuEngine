
import pygame

button_sound = pygame.mixer.Sound('moyu_engine/assets/sound/click5.ogg')

bgm = pygame.mixer.music.load('moyu_engine/assets/music/Grace Behind the Curtain - Silent Partner.mp3')